import Text.Parsec.String
import Text.Parsec hiding (many, token, (<|>))
import Control.Applicative
import Data.Char
import Text.Parsec.Combinator
import Control.Applicative
import Text.Parsec.Char
import qualified Data.Map as M
import Control.Monad

infixr 5 <:>
(<:>) :: Applicative f => f a -> f [a] -> f [a] 
a <:> b = (:) <$> a <*> b

parseDigit :: Parser Int
parseDigit = digitToInt <$> digit

parseNumber :: Parser Int
parseNumber = read <$> many1 digit

parseNegative :: Parser Int
parseNegative = read <$> char '-' <:> many1 digit

main :: IO()
main = do
	putStrLn $ show $ interpret example

symbol :: Char -> Parser Char
symbol = token . char

integer :: Parser Int
integer = number <|> negative

number :: Parser Int
number = read <$> many1 digit

negative :: Parser Int
negative = read <$> char '-' <:> many1 digit

ppsp a b = printParse $ simpleParse a b

printParse :: Either ParseError Int -> IO()
printParse (Left str) = putStrLn $ show str
printParse (Right i)  = putStrLn $ show i


data Expression = Val   Int
                | Var   String
                | Plus  Expression Expression
                | Minus Expression Expression
                  deriving Show

data Assignment = Assignment String Expression deriving Show

type Program = [Assignment]
                             
type VarTable = M.Map String Int

eval :: VarTable -> Expression -> Maybe Int
eval vt e = case e of (Val   v)   -> Just v
                      (Var   v)   -> M.lookup v vt
                      (Plus  a b) -> (+) <$> eval vt a <*> eval vt b
                      (Minus a b) -> (-) <$> eval vt a <*> eval vt b
                      
assign :: Assignment -> VarTable -> Maybe VarTable
assign (Assignment v e) vt = insert v vt <$> eval vt e
    where insert k = flip (M.insert k)
    
run :: Program -> Maybe VarTable
run = run' (Just M.empty)
    where run' vt []     = vt
          run' vt (a:as) = run' (join $ assign a <$> vt) as

variable :: Parser String
variable = token $ letter <:> many alphaNum


token :: Parser a -> Parser a
token = (<* spaces)


betterParse :: Parser a -> String -> Either ParseError a
betterParse p = parse (spaces *> p) err

integer' = token integer

assignment :: Parser Assignment
assignment = Assignment <$> variable <*> (symbol '=' *> expression)

program :: Parser Program
program = many1 assignment

interpret :: String -> Maybe VarTable
interpret s = case prog of Left  e -> Nothing
                           Right p -> run   p
    where prog = betterParse program s
    
operator :: Parser (Expression -> Expression -> Expression)
operator = plus <|> minus
    where plus  = symbol '+' *> return Plus
          minus = symbol '-' *> return Minus

expression :: Parser Expression
expression = term `chainl1` operator
    where term = val <|> var
          var  = Var <$> variable
          val  = Val <$> integer'


example = "a = 7 - 9 + 3 + 15\nb = a - 9\nc = a + a + b\na = c + b"
