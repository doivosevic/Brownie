import Text.Parsec(many1, char, digit, letter, alphaNum, spaces, parse, string)
--import Text.Parsec.Char
import Text.ParserCombinators.Parsec(try)
import Text.Parsec.Combinator
import Text.Parsec.String(Parser)
import Text.Parsec.Expr(Operator, Operator(Infix), Assoc(AssocLeft), buildExpressionParser)
import Control.Applicative(Applicative, many, (<$>), (<*>), (<|>), (<*), (<$), (*>))
import Control.Monad(join)
--import Data.Char
import Data.Functor.Identity(Identity)
import Data.Maybe(fromMaybe, fromJust, isJust)
import qualified Data.Map as M

infixr 5 <:>
(<:>) :: Applicative f => f a -> f [a] -> f [a] 
a <:> b = (:) <$> a <*> b

--pure :: a -> f a
--Lift a value.

--(<*>) :: f (a -> b) -> f a -> f b infixl 4
--Sequential application.

--(*>) :: f a -> f b -> f b infixl 4
--Sequence actions, discarding the value of the first argument.

--(<*) :: f a -> f b -> f a infixl 4
--Sequence actions, discarding the value of the second argument.

--(<|>) :: f a -> f a -> f a infixl 3
--An associative binary operation

-- (<$>) :: Functor f => (a -> b) -> f a -> f b infixl 4 <$>

main :: IO()
main = 
	print $ interpret example

symbol :: Char -> Parser Char
symbol = (<* spaces) . char


number :: Parser Int
number = read <$> many1 digit

negative :: Parser Int
negative = read <$> char '-' <:> many1 digit


data Expression = Val   Int
                | Booly  Bool
                | Var   String
                | Plus  Expression Expression
                | Minus Expression Expression
                | Mult  Expression Expression
                | Div   Expression Expression
                  deriving (Show)

data Statement = Assignment String Expression
               | If Expression Statement (Maybe Statement)
                deriving (Show)

type VarTable = M.Map String Int

eval :: VarTable -> Expression -> Maybe Int
eval vt e = case e of (Val   v)   -> Just v
                      (Var   v)   -> M.lookup v vt
                      (Plus  a b) -> (+) <$> eval vt a <*> eval vt b
                      (Minus a b) -> (-) <$> eval vt a <*> eval vt b
                      (Mult  a b) -> (*) <$> eval vt a <*> eval vt b
                      (Div   a b) -> div <$> eval vt a <*> eval vt b

makeStatement :: Statement -> VarTable -> Maybe VarTable
makeStatement (If e st mst) vt
  | fromMaybe 0 (eval vt e) /= 0    = makeStatement st vt
  | isJust mst                      = makeStatement (fromJust mst) vt
  | otherwise                       = Just vt
makeStatement (Assignment v e) vt = insert v vt <$> eval vt e
    where insert k = flip (M.insert k)

run :: [Statement] -> Maybe VarTable
run = run' (Just M.empty)
    where run' = foldl (\ vt a -> join $ makeStatement a <$> vt)
-- foldl :: (a -> b -> a) -> a -> [b] -> a
-- join :: Monad m => m (m a) -> m a

assignment :: Parser Statement
assignment = do
  spaces
  string "$"
  var <- variable
  spaces
  char '='
  spaces
  expr <- expression
  return $ Assignment var expr
--assignment = Assignment <$> variable <*> (symbol '=' *> expression)

parseIf :: Parser Statement
parseIf = do
  spaces
  string "if "
  spaces
  expr <- expression
  spaces
  string "then "
  st <- statement
  mst <- (optionMaybe $ string "else " *> statement)
  return $ If expr st mst

statement :: Parser Statement
statement = parseIf <|> assignment

interpret :: String -> Maybe VarTable
interpret s = case parse (many1 statement) "error" s of 
                Left  _ -> Nothing
                Right p -> run   p

-- Both of our operators have the same priority
table :: [[Operator String () Identity Expression]]
table =  [[binary '*' Mult, binary '/' Div], [binary '+' Plus, binary '-' Minus]]
        where binary name f = Infix (f <$ symbol name) AssocLeft
        
expression :: Parser Expression
expression = buildExpressionParser table other
    where other = var <|> val
          var  = Var <$> ((<* spaces) $ letter <:> many alphaNum)
          val  = Val <$> ((<* spaces) $ number <|> negative)

variable :: Parser String
variable = (<* spaces) $ letter <:> many alphaNum
--integer :: Parser Int
--integer = (<* spaces) $ number <|> negative

{-
operator :: Parser (Expression -> Expression -> Expression)
operator = plus <|> minus
    where plus  = symbol '+' *> return Plus
          minus = symbol '-' *> return Minus

expression :: Parser Expression
expression = term `chainl1` operator
    where term = val <|> var
          var  = Var <$> ((<* spaces) $ letter <:> many alphaNum)
          val  = Val <$> ((<* spaces) $ number <|> negative)
-}

example :: String
example = "$a = 2 * 3 + 1\n$c = 14\nif 0 then $b = 2 else $a = 1"
--example2 = "a = 7 - 9 + 3 + 15\nb = a - 9\nc = a + a + b\na = c + b"


{-
err = "An error has occurred"

simpleParse :: Parser a -> String -> Either ParseError a
simpleParse p = parse p err

parseDigit :: Parser Int
parseDigit = digitToInt <$> digit

parseNumber :: Parser Int
parseNumber = read <$> many1 digit

parseNegative :: Parser Int
parseNegative = read <$> char '-' <:> many1 digit

ppsp a b = printParse $ simpleParse a b

printParse :: Either ParseError Int -> IO()
printParse (Left str) = print str
printParse (Right i)  = print i


-- many1 :: Stream s m t => ParsecT s u m a -> ParsecT s u m [a]
--program :: Parser [Assignment]
--program = many1 assignment

-- parse :: Stream s Data.Functor.Identity.Identity t => Parsec s () a -> SourceName -> s -> Either ParseError a


-- :: Parser -> String forParsing -> Either ParseError [Assignment]
--betterParse :: Parser a -> String -> Either ParseError a
--betterParse p = parse (spaces *> p) "An error has occurred"
-}


{-
popis za skuženje:
many1 tj liftM2
-}