module Test_Parser where

import Text.Parsec(char, digit, letter, alphaNum, spaces, parse, string)
--import Text.Parsec.Char
import Text.ParserCombinators.Parsec(try)
import Text.ParserCombinators.Parsec.Char
import Text.Parsec.Combinator
import Text.Parsec.Error
import Text.Parsec.String
import Text.Parsec.Expr(Operator, Operator(Infix), Assoc(AssocLeft), buildExpressionParser)
import Control.Applicative(Applicative, many, (<$>), (<*>), (<|>), (<*), (<$), (*>))
--import Control.Monad(join)
import Data.Char
import Data.Functor.Identity(Identity)
--import Data.Maybe
--import qualified Data.Map as M

import Test_Types

infixr 5 <:>
(<:>) :: Applicative f => f a -> f [a] -> f [a] 
a <:> b = (:) <$> a <*> b

number :: Parser Int
number = read <$> many1 digit

negative :: Parser Int
negative = read <$> char '-' <:> many1 digit

stringInSpaces :: String -> Parser String
stringInSpaces str = spaces *> string str <* spaces

assignment :: Parser Statement
assignment = Assignment <$> (stringInSpaces "$" *> variable) <*> (stringInSpaces "=" *> expression)

parseIf :: Parser Statement
parseIf = If <$> (stringInSpaces "if " *> expression) <*> (stringInSpaces "then " *> statement)

parseIfElse :: Parser Statement
parseIfElse = IfElse <$> (stringInSpaces "if " *> expression) <*> (stringInSpaces "then " *> statement) <*> (stringInSpaces "else " *> statement)

statement :: Parser Statement
statement = try parseIfElse <|> parseIf <|> assignment <|> nakedExpression

nakedExpression :: Parser Statement
nakedExpression = Exp <$> expression

table :: [[Operator String () Identity Expression]]
table =  [[binary "*" Mult, binary "/" Div], [binary "+" Plus, binary "-" Minus]]
        where binary name f = Infix (f <$ stringInSpaces name) AssocLeft
        
expression :: Parser Expression
expression = buildExpressionParser table other
    where other = var <|> val
          var  = Var <$> ((<* spaces) $ letter <:> many alphaNum)
          val  = Val <$> ((<* spaces) $ number <|> negative)

variable :: Parser String
variable = (<* spaces) $ letter <:> many alphaNum

example :: String
example = "$a = 2 * 3 + 1\n$c = 14\nif 1 then $b = 2 else $a = 1\nif 1 then if 3 then $asd = 123 else $a = 1\n$as = 23 $a = 123 23"
