module Test_Types where

import qualified Data.Map.Strict as M

data Expression = Val   Int
                | Booly  Bool
                | Var   String
                | Plus  Expression Expression
                | Minus Expression Expression
                | Mult  Expression Expression
                | Div   Expression Expression
                | Cmd String [String]
                  deriving (Show)

data Statement = Assignment String Expression
               | If Expression Statement
               | IfElse Expression Statement Statement
               | Exp Expression
                deriving (Show)

data Value  = VBool Bool
            | VFloat Float
            deriving (Show)

type VarTable = M.Map String Int


instance Convert Bool where
  toValue = VBool
  fromValue (VBool a) = a
  fromValue _ = error "Looking for bool but received something else!"

instance Convert Float where
  toValue = VFloat
  fromValue (VFloat a) = a
  fromValue _ = error "Looking for float but received something else!"

class Convert a where
    toValue :: a -> Value
    fromValue :: Value -> a