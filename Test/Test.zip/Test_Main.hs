import Text.Parsec(char, digit, letter, alphaNum, spaces, parse, string)
--import Text.Parsec.Char
import Text.ParserCombinators.Parsec(try)
import Text.ParserCombinators.Parsec.Char
import Text.Parsec.Combinator
import Text.Parsec.Error
import Text.Parsec.String
import Text.Parsec.Expr(Operator, Operator(Infix), Assoc(AssocLeft), buildExpressionParser)
import Control.Applicative(Applicative, many, (<$>), (<*>), (<|>), (<*), (<$), (*>))
--import Control.Monad(join)
import Data.Char
import Data.Functor.Identity(Identity)

import Test_Parser
import Test_Interpret
import Test_Types

main :: IO()
main = 
	--print $ interpret example
	print $ interpret example
  --print' $ parse (many1 statement) "error" example

print' :: Either ParseError [Statement] -> IO()
print' (Right a) = putStrLn $ unlines $ map show a
print' (Left err) = print err